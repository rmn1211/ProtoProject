@extends('heafoo')

@section('page-content')

    <section>
        <h3 class ="font-bold  text-2xl">Wilkommen auf BSWeb</h3>
        <p class="text-gray-100 pt-2"> Wenn Sie Kapitän oder Staffelleiter sind, können Sie sich hier anmelden</p>
    </section>
    

   
@endsection