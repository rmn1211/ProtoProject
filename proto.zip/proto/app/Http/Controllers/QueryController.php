<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QueryController extends Controller
{
    //SELECT QUERIES FROM DUELL
    public static function getResults($id)
    {
        //$change = DB::connection('mysqlrep')->update('update duell set Schiedsrichter = "Günther Jauch" where id = ?', [$id]);
       $results = DB::select('select * from duell where spiel_ID = ?', [$id]);
       
        //$foo =DB::connection('mysqlrep')->insert('insert into region (Name, Sportart) Values ("Köln-Bonn", 1)');
       // $satz = DB::connection('mysqlrep')->select('select * from satz where duell_ID = ? and Satz_Nr = 3',[$id]);
        //$region = DB::connection('mysqlrep')->select('select * from region');
       return $results;
    }

    public static function getOrt($id)
    {
        //$ort = DB::select('select ort from spiel where ID = ?', [$id]);
        $place = DB::table(DB::raw('spiel'))
        ->where(DB::raw('ID'), [$id])
        ->pluck('Ort');
        return $place;
    }

    public static function getHome($id)
    {
        //$home = DB::select('select m.name from spiel s,mannschaft m where s.Heim = m.Verein_ID and s.ID = ?', [$id]);
        $home = DB::table(DB::raw('spiel s, mannschaft m'))
        ->where(DB::raw('s.Heim = m.Verein_ID and s.ID'), [$id])
        ->pluck('m.name');
        return $home;
    }
    public static function getAway($id)
    {
        $away = DB::table(DB::raw('spiel s, mannschaft m'))
        ->where(DB::raw('s.Gast = m.Verein_ID and s.ID'), [$id])
        ->pluck('m.name');
        return $away;
    }
   
    public function updateOrt($id,Request $request)
    {
        $place = $request->tfPlace;
        #$id = $request -> match;
        $set = DB::table(('spiel'))
        ->where(DB::raw('ID'), [$id])
        ->update(['Ort'=>$place]);
    }
}
