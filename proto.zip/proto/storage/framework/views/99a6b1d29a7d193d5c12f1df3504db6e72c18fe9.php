<?php $__env->startSection('page-content'); ?>

    <section>
        UNDER CONSTRUCTION
      </section>
    

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('heafoo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/roman/workspace/laravelProto/proto/resources/views/report/overview.blade.php ENDPATH**/ ?>